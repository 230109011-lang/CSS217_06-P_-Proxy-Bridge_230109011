public class Main {
    public static void main(String[] args) {
        System.out.println("===== Task 1: The Bouncer =====");
        Image guestImage = new ProxyImage("salary_sheet.png", "GUEST");
        Image adminImage = new ProxyImage("salary_sheet.png", "ADMIN");
        guestImage.show();
        adminImage.show();

        System.out.println("\n===== Task 2: The View Counter =====");
        Video video = new ProxyVideo("Cat_Memes.mp4");
        video.play();
        video.play();
        video.play();

        System.out.println("\n===== Task 3: School Wi-Fi Firewall =====");
        Internet internet = new SchoolProxyInternet();
        internet.connectTo("wikipedia.org");
        internet.connectTo("gaming.com");

        System.out.println("\n===== Task 4: The New Machine =====");
        Device light = new SmartLight();
        AdvancedRemote remote = new AdvancedRemote(light);
        remote.powerOn();
        remote.mute();

        System.out.println("\n===== Task 5: The New Button =====");
        PartyRemote partyRemote = new PartyRemote(new Radio());
        partyRemote.partyMode();

        System.out.println("\n===== Task 6: RPG Weapon System =====");
        Knight swordKnight = new Knight(new Sword());
        swordKnight.attack();
        Knight wandKnight = new Knight(new MagicWand());
        wandKnight.attack();
    }
}
